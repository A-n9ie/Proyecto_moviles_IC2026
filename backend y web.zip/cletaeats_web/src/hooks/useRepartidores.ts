import { createEntityHooks } from '../lib/react-query/createEntityHooks'
import { repartidoresService } from '../services/repartidores/repartidoresService'
import { queryKeys } from '../lib/react-query/queryKeys'
import { notificationService } from '../services/ui/notificationService'
import { confirmService } from '../services/ui/confirmService'
import type { Repartidor, RepartidorRequest } from '../types/repartidores'
import { useMutation, useQueryClient } from '@tanstack/react-query'

const hooks = createEntityHooks<Repartidor, RepartidorRequest>(
    queryKeys.repartidores,
    repartidoresService,
)

export const useRepartidores = () => {
    const query     = hooks.useList()
    const createMut = hooks.useCreate()
    const updateMut = hooks.useUpdate()
    const removeMut = hooks.useRemove()
    const queryClient = useQueryClient()

    const amonestacionMut = useMutation({
        mutationFn: ({ id, motivo }: { id: number; motivo: string }) =>
            repartidoresService.agregarAmonestacion(id, motivo),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: queryKeys.repartidores }),
    })

    const handleAmonestacion = async (repartidor: Repartidor) => {
        const motivo = window.prompt(`Motivo de la amonestación para "${repartidor.nombre}":`)
        if (motivo === null) return   // canceló
        try {
            const result = await amonestacionMut.mutateAsync({ id: repartidor.id, motivo })
            notificationService.success(result.mensaje)
        } catch (e: any) {
            notificationService.error(e?.message ?? 'Error al registrar amonestación')
        }
    }
    const handleSubmit = async (data: RepartidorRequest, repartidor?: Repartidor | null) => {
        try {
            if (repartidor) {
                await updateMut.mutateAsync({ id: repartidor.id, body: data })
                notificationService.success('Repartidor actualizado')
            } else {
                await createMut.mutateAsync(data)
                notificationService.success('Repartidor creado')
            }
        } catch (e: any) {
            notificationService.error(e?.message ?? 'Error guardando repartidor')
            throw e
        }
    }

    const handleToggleEstado = async (repartidor: Repartidor) => {
        const estaActivo = repartidor.estado === 1
        const ok = await confirmService.confirm(
            `¿Querés ${estaActivo ? 'bloquear' : 'desbloquear'} la cuenta de "${repartidor.nombre}"?`
        )
        if (!ok) return
        try {
            await updateMut.mutateAsync({
                id: repartidor.id,
                body: { estado: estaActivo ? 0 : 1 } as any,
            })
            notificationService.success(`Cuenta ${estaActivo ? 'bloqueada' : 'desbloqueada'}`)
        } catch (e: any) {
            notificationService.error(e?.message ?? 'Error cambiando estado de cuenta')
        }
    }


    const handleDelete = async (repartidor: Repartidor) => {
        const ok = await confirmService.delete(repartidor.nombre)
        if (!ok) return
        try {
            await removeMut.mutateAsync(repartidor.id)
            notificationService.success('Repartidor eliminado')
        } catch (e: any) {
            notificationService.error(e?.message ?? 'Error eliminando repartidor')
        }
    }

    return {
        repartidores: query.data ?? [],
        loading:      query.isLoading,
        error:        query.error,
        handleSubmit,
        handleToggleEstado,
        handleDelete,
        handleAmonestacion,
        creating:     createMut.isPending,
        updating:     updateMut.isPending,
    }
}