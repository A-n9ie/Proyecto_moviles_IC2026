import { useEffect, useState } from 'react'
import { axiosClient } from '../../services/api/axiosClient'

interface Evento {
    ID: number
    USUARIO_ID: number | null
    ROL: string
    ACCION: string
    DETALLE: string
    FECHA: string
}

const ACCION_LABEL: Record<string,string> = {
    LOGIN:            '🔐 Inicio de sesión',
    PEDIDO_CREADO:    '🛒 Pedido creado',
    PEDIDO_CANCELADO: '❌ Pedido cancelado',
    PEDIDO_ENTREGADO: '✅ Pedido entregado',
    TARJETA_AGREGADA: '💳 Tarjeta agregada',
    TARJETA_ELIMINADA:'🗑️ Tarjeta eliminada',
    PERFIL_EDITADO:   '✏️ Perfil editado',
}

export default function BitacoraPage(){
    const [eventos, setEventos] = useState<Evento[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(()=>{
        axiosClient.get<Evento[]>('/admin/bitacora')
            .then(r => setEventos(r.data))
            .catch(() => setEventos([]))
            .finally(() => setLoading(false))
    },[])

    return (
        <div>
            <h2>Bitácora de auditoría</h2>
            {loading ? <p>Cargando...</p> : (
                <table style={{width: '100%', borderCollapse: 'collapse'}}>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Rol</th>
                            <th>Acción</th>
                            <th>Detalle</th>
                            <th>Usuario ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {eventos.map(e => (
                            <tr key={e.ID}>
                                <td>{e.FECHA}</td>
                                <td>{e.ROL}</td>
                                <td>{ACCION_LABEL[e.ACCION] ?? e.ACCION}</td>
                                <td>{e.DETALLE}</td>
                                <td>{e.USUARIO_ID ?? '—'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    )
}
